package org.example.transactionmanager.Entity;

public enum TransactionType {
    INCOME, EXPENSE
}